Currently only tested and thus know to work on Fedora 37 Workstation. More to come.
Welcome message can be changed [data>flutter_assets>assets>message.txt]
Kilroy Was Here